# -*- coding: utf-8 -*-
#
# The code is completely modified and optimized by Dorik1972
#
from __future__ import print_function
import os, sys, glob
import gzip, time, random, re
from . import log, isDreamOS
try:
	from xml.etree.cElementTree import iterparse
except ImportError:
	from xml.etree.ElementTree import iterparse
from xml.sax.saxutils import unescape
from collections import defaultdict
try:
	import cPickle as pickle
except ImportError:
	import pickle

PY3 = (sys.version_info[0] == 3)

try:
	try:
		import lzma
	except ImportError:
		import subprocess
		subprocess.call(["opkg", "install", "python3-lzma" if PY3 else "python-lzma"])
		import lzma
except:
	try:
		from backports import lzma
	except ImportError:
		import subprocess
		subprocess.call(["apt" if isDreamOS else "opkg", "install", "python3-backports-lzma" if PY3 else "python-backports-lzma"])
		from backports import lzma

# User selection stored here
SETTINGS_FILE = '/etc/epgimport/epgimport.conf'
channelCache = {}

def isLocalFile(filename):
	# we check on a '://' as a silly way to check local file
	return '://' not in filename

def xml_unescape(text):
	"""
	:param text: The text that needs to be unescaped.
	:type text: str
	:rtype: str
	"""
	return re.sub(r'&nbsp;|\s+', ' ', unescape((text if PY3 else text.encode('utf-8')).strip(),
						entities={
								"&laquo;": "«",
								"&raquo;": "»",
								"&apos;": "'",
							})
				) if isinstance(text, str if PY3 else basestring) else ''


def getChannels(path, name=None):
	global channelCache
	if name in channelCache:
		return channelCache[name]
	dirname, filename = os.path.split(path)
	if name:
		channelfile = os.path.join(dirname, name) if isLocalFile(name) else name
	else:
		channelfile = os.path.join(dirname, filename.split('.', 1)[0] + '.channels.xml')
	try:
		return channelCache[channelfile]
	except KeyError:
		channelCache[channelfile] = EPGChannel(channelfile)
		return channelCache[channelfile]

def enumerateXML(fp, tag=None):
	"""Enumerates ElementTree nodes from file object 'fp'"""
	doc = iterparse(fp, events=('start', 'end'))
	_, root = next(doc)
	depth = 0
	for event, element in doc:
		if element.tag == tag:
			if event == 'start':
				depth += 1
			else:
				depth -= 1
				if depth == 0:
					yield element
					root.clear()
		if event == 'end' and element.tag != tag:
			root.clear()

class EPGChannel(object):
	def __init__(self, filename, urls=None):
		self.mtime = None
		self.name = filename
		self.urls = [filename] if urls is None else urls
		self.items = None

	def openStream(self, filename):
		try:
			if not os.path.getsize(filename):
				raise Exception("file is empty")
			if not filename.endswith(('.gz', '.xz','.lzma', '.xml')):
				raise Exception("unsupported compression type: %s" % os.path.splitext(filename)[1][1:])
		except Exception as e:
			raise Exception("[EPGConfig] Unexpected error occurred with lookup table file: %s" % filename)

		if filename.endswith('.gz'):
			try:
				fd = gzip.open(filename, 'rb')
				# read a bit to make sure it's a gzip file
				fd.read(10)
				fd.seek(0,0)
			except Exception as e:
				raise Exception("[EPGConfig] Lookup table file is not a valid gzip file %s" % filename)

		elif filename.endswith(('.xz','.lzma')):
			try:
				fd = lzma.open(filename, 'rb')
				# read a bit to make sure it's an xz file
				fd.read(10)
				fd.seek(0,0)
			except Exception as e:
				raise Exception("[EPGConfig] Lookup table file is not a valid xz file: %s" % filename)
		else:
			fd = open(filename, 'rb')

		return fd

	def parse(self, filterCallback, downloadedFile):
		""" parse  *****_cahnnels.xml lookup table file """
		print("[EPGConfig] Enumerating channels lookup table XML file", file=log)
		self.items = defaultdict(set) # set make the reference unique to avoid loading twice the same EPG data.
		count = 0
		try:
			for elem in enumerateXML(self.openStream(downloadedFile), 'channel'):
				count += 1
				id, ref = list(map(xml_unescape, [elem.get('id').lower(), elem.text]))
				if id and ref and filterCallback(ref):
					self.items[id].add(ref)

			print("[EPGConfig] Processed: %s channels" % count, file=log)
		except Exception as e:
			print("[EPGConfig] failed to parse", self.name, "Error:", e, file=log)
		else:
			print("[EPGConfig] Formed lookup table for: %s channels id" % len(self.items), file=log)

	def update(self, filterCallback, downloadedFile=None):
		if downloadedFile is not None:
			self.mtime = time.time()
			return self.parse(filterCallback, downloadedFile)
		elif len(self.urls) == 1 and isLocalFile(self.urls[0]):
			mtime = os.path.getmtime(self.urls[0])
			if (not self.mtime) or (self.mtime < mtime):
				self.parse(filterCallback, self.urls[0])
				self.mtime = mtime

	def downloadables(self):
		if not (len(self.urls) == 1 and isLocalFile(self.urls[0])):
			# Check at most once a day
			now = time.time()
			if (not self.mtime) or (self.mtime + 86400 < now):
				return self.urls
		return None

	def __repr__(self):
		return "EPGChannel(urls=%s, channels=%s, mtime=%s)" % (self.urls, self.items and len(self.items), self.mtime)


class EPGSource(object):
	def __init__(self, path, elem, category=None):
		self.parser = elem.get('type', 'gen_xmltv')
		self.nocheck = int(elem.get('nocheck', 0))
		self.urls = [xml_unescape(e.text) for e in elem.findall('url')]
		self.url = random.choice(self.urls)
		self.description = xml_unescape(elem.findtext('description', self.url))
		self.category = category
		self.format = elem.get('format', 'xml')
		self.channels = getChannels(path, elem.get('channels'))


def enumSourcesFile(sourcefile, filter=None, categories=False):
	""" parse  /etc/epgimport/*****.sources.xml """
	global channelCache
	category = None

	for event, elem in iterparse(sourcefile, events=("start", "end")):
		if event == 'end':
			if elem.tag == 'source':
				s = EPGSource(sourcefile, elem, category)
				elem.clear()
				if (filter is None) or (s.description in filter):
					yield s
			elif elem.tag == 'channel':
				name = xml_unescape(elem.get('name'))
				urls = [xml_unescape(e.text) for e in elem.findall('url')]
				if name in channelCache:
					channelCache[name].urls = urls
				else:
					channelCache[name] = EPGChannel(name, urls)
			elif elem.tag == 'sourcecat':
				category = None
		elif event == 'start':
			# Need the category name sooner than the contents, hence "start"
			if elem.tag == 'sourcecat':
				category = xml_unescape(elem.get('sourcecatname'))
				if categories:
					yield category

def enumSources(path, filter=None, categories=False):
	try:
		for file in glob.iglob(os.path.join(path, '*.sources.xml')):
			for s in enumSourcesFile(file, filter, categories):
				yield s
	except Exception as e:
		print("[EPGConfig] EPGConfig enumSources Error:", e, file=log)

def loadUserSettings(filename=SETTINGS_FILE):
	try:
		return pickle.load(open(filename, 'rb'))
	except Exception as e:
		print("[EPGConfig] No settings", e, file=log)
		return {"sources": []}

def storeUserSettings(filename=SETTINGS_FILE, sources=[]):
	container = {"sources": sources}
	pickle.dump(container, open(filename, 'wb'), pickle.HIGHEST_PROTOCOL)
