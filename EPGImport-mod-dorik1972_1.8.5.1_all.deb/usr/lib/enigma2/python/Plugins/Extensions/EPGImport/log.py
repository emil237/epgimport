# logging
#
# One can simply use
# import log
# print>>log, "Some text"
# because the log unit looks enough like a file!
#
# The code is completely modified and optimized by Dorik1972
#

import sys
import threading
PY3 = (sys.version_info[0] == 3)
if PY3:
	from io import StringIO
else:
	from cStringIO import StringIO

logfile = StringIO()
# Need to make our operations thread-safe.
_lock = threading.Lock()

def write(data):
	with _lock:
		if logfile.tell() > 32000:
			# Do a sort of 32k round robin
			logfile.truncate(0)
			logfile.seek(0)
			logfile.reset()

		logfile.write(data)
	sys.stdout.write(data)

def getvalue():
	with _lock:
		pos = logfile.tell()
		head = logfile.read()
		logfile.seek(0)
		tail = logfile.read(pos)
	return head + tail

