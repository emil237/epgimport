# -*- coding: utf-8 -*-
from __future__ import print_function
from . import isDreamOS, log
from .EPGImport import bigStorage, HDD_EPG_DAT
import os, sys
if isDreamOS:
	from . import epgdb
	from Components.config import config
else:
	from . import epgdat

# Hack to make this test run on Windows (where the reactor cannot handle files)
if sys.platform.startswith('win'):
	tmppath = '.'
	settingspath = '.'
else:
	tmppath = bigStorage(9000000, '/tmp', '/media/cf', '/media/mmc', '/media/usb', '/media/hdd')
	settingspath = '/etc/enigma2'

class epgdatclass(object):

	def __init__(self):
		self.data = None
		self.services = None

		if isDreamOS:
			self.epgfile = config.misc.epgcache_filename.value
			self.epg = epgdb.epgdb_class("EPGImport", 0, self.epgfile, config.plugins.epgimport.clear_oldepg.value)
		else:
			self.epgfile = os.path.join(tmppath, 'epg_new.dat')
			self.epg = epgdat.epgdat_class(tmppath, settingspath, self.epgfile)

		print ("[EPGImport] EPG database located at %s" % self.epgfile, file=log)

	def importEvents(self, services, dataTupleList):
		'This method is called repeatedly for each bit of data'
		if services != self.services:
			self.commitService()
			self.services = services
		for program in dataTupleList:
			program = list(program)
			program[3] = '%s\n%s' % program[3:5] if program[3] else program[4]
			program = program[:4] + program[-1:] if isDreamOS else program[:4]
			self.epg.add_event(*program)

	def commitService(self):
		if self.services is not None:
			self.epg.preprocess_events_channel(self.services)

	def epg_done(self):
		try:
			self.commitService()
			self.epg.final_process()
		except:
			print("[EPGImport] Failure in epg_done")
			import traceback
			traceback.print_exc()
		self.epg = None

	def __del__(self):
		'Destructor - finalize the file when done'
		if self.epg is not None:
			self.epg_done()
