#!/usr/bin/python
from __future__ import print_function
import os
import time
import shutil

MEDIA = ("/media/hdd/", "/media/usb/", "/media/mmc/", "/media/cf/", "/tmp")

def findEpg():

	candidates = [os.path.join(p, "epg.dat") for p in MEDIA if os.path.isfile(os.path.join(p, "epg.dat"))]
	candidates.sort(key=lambda f: os.path.getctime(f))
	# best candidate is most recent filename.
	return candidates[-1] if candidates else None


def checkCrashLog():
	for path in MEDIA[:-1]:
		try:
			dirList = os.listdir(path)
			for fname in dirList:
				if fname[0:13] == 'enigma2_crash':
					try:
						crashtime = 0
						crashtime = int(fname[14:24])
						howold = time.time() - crashtime
					except:
						print("no time found in filename")
					if howold < 120:
						print("recent crashfile found analysing")
						with open(path + fname, "r") as crashfile:
							crashtext = crashfile.read()
						if (crashtext.find("FATAL: LINE ") != -1):
							print("string found, deleting epg.dat")
							return True
		except:
			pass
	return False


def findNewEpg():
	for path in MEDIA:
		fn = os.path.join(path, 'epg_new.dat')
		if os.path.exists(fn):
			return fn


epg = findEpg()
newepg = findNewEpg()

print("Epg.dat found at : ", epg)
print("newepg  found at : ", newepg)

##Delete epg.dat if last crash was because of error in epg.dat
if checkCrashLog():
	try:
		os.unlink(epg)
	except:
		print("delete error")

##if excists cp epg_new.dat epg.dat
if newepg:
	if epg:
		print("replacing epg.dat with newmade version")
		os.unlink(epg)
		shutil.copy2(newepg, epg)
