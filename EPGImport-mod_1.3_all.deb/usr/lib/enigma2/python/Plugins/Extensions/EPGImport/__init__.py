# -*- coding: utf-8 -*-
#
# The code is completely modified and optimized by Dorik1972
#
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
from os import environ, path

def isDreamOS():
	'''
	return True -- for commercial versions of Enigma2 core (OE 2.2+) - DreamElite, DreamOS, Merlin, ... etc.
	return False - for open-source versions of Enigma2 core (OE 2.0 or OE-Alliance 4.x) - OpenATV, OpenPLi, VTi, TeamBlue ... etc.
	'''
	try:
		from enigma import PACKAGE_VERSION
		major, minor, patch = map(int, PACKAGE_VERSION.split('.')[:3])
		assert (major, minor, patch) >= (4, 2, 0)
		return True
	except (AssertionError, ValueError, ImportError):
		return False

isDreamOS = isDreamOS()

def localeInit():
	lang = language.getLanguage()[:2]
	environ['LANGUAGE'] = lang
	gettext.bindtextdomain(PluginLanguageDomain, getFullPath('locale'))

PluginLanguageDomain = 'EPGImport'
getFullPath = lambda fname: resolveFilename(SCOPE_PLUGINS, path.join('Extensions', PluginLanguageDomain, fname))
_ = lambda txt: (gettext.dgettext(PluginLanguageDomain, txt) if txt else '')
localeInit()
language.addCallback(localeInit)
