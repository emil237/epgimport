# -*- coding: utf-8 -*-
#
# The code is completely modified and optimized by Dorik1972
#
from __future__ import print_function
import calendar, time
from . import log, isDreamOS
import re
from Components.Language import language
from .EPGConfig import xml_unescape, enumerateXML
from .EPGImport import ISO639_associations

LANG = language.getLanguage()[:2]

class XMLTVConverter(object):
	def __init__(self, channels_dict, category_dict, dateformat='%Y%m%d%H%M%S %Z'):
		self.channels = channels_dict
		self.categories = category_dict
		self.dateParser = lambda x: time.struct_time(tuple(map(int, (x[0:4], x[4:6], x[6:8], x[8:10], x[10:12]))) + (0, -1, -1, 0)) if dateformat.startswith('%Y%m%d%H%M%S') else time.strptime(x, dateformat)

	@staticmethod
	def get_xml_string(elem, name):
		r = ''
		try:
			for node in elem.iter(name):
				value = node.text
				if value:
					value = xml_unescape(value)
					if LANG == node.get('lang', None):   #Priority is given to the Enigma2 interface language
						r = value
						break
					elif not r:
						r = value
		except Exception as e:
			print("[XMLTVConverter] get_xml_string error:", e)

		# Now returning UTF-8 by default and normalizing pinning marks, the epgdat/oudeis must be adjusted to make this work.
		return re.sub(r'\s+(?=(?:[,.?!:;…]))', r'', r) if r else ''


	@staticmethod
	def get_timestamp_utc(xmltv_date_str, fdateparse):
		try:
			return calendar.timegm(fdateparse(xmltv_date_str[:-6])) - (3600 * int(xmltv_date_str[-5:]) / 100)
		except Exception as e:
			print("[XMLTVConverter] get_time_utc error:", e)
			return 0

	def get_category(self, cat, duration):
		if not isinstance(cat, str):
			return 0
		category = self.categories.get(cat, '')
		if len(category) > 1 and duration > 60 * category[1]:
			return category[0]
		elif len(category) > 0:
			return category
		return 0

	def enumFile(self, fileobj):
		if not self.channels:
			print("[XMLTVConverter] There is nothing no enumerate. There are no channels loaded", file=log)
			return

		print("[XMLTVConverter] Enumerating XMLTV event information", file=log)
		count = 0
		now_timestamp_utc = int(time.time())

		for elem in enumerateXML(fileobj):
			if 'channel' not in elem.attrib:
				continue
			count+=1
			try:
				data_tuple = None
				channel = elem.attrib['channel'].lower()
				if channel in self.channels:
					t = list(map(lambda x: XMLTVConverter.get_timestamp_utc(elem.get(x), self.dateParser), ['start', 'stop']))
					if not (not (t[1] and t[0]) or t[1]<=t[0] or t[1]<=now_timestamp_utc):
						l = list(map(lambda x: XMLTVConverter.get_xml_string(elem, x), ['title', 'sub-title', 'desc', 'category']))
						if isDreamOS:
							l.append(ISO639_associations.get(LANG, 'eng'))
						t[1] -= t[0]
						l[3] = self.get_category(l[3], t[1])
						data_tuple = (self.channels[channel], tuple(t+l))
			except Exception as e:
				print("[XMLTVConverter] parsing event error:", e)
			finally:
				# here we get a tuple of tuples ;) or None
				# return a None object to give up time to the reactor.
				# 1. start time (long)
				# 2. duration (int)
				# 3. event title (string)
				# 4. short description (string)
				# 5. extended description (string)
				# 6. event type (byte)
				# 7. ISO639_2 three-letter abbreviation langguage code (string)  !!! For DreamOS onnly !!!
				t = int(time.time())
				if t - now_timestamp_utc >= 10:
					print("[XMLTVConverter] Processed: %s events" % count, file=log)
					now_timestamp_utc = t

				yield data_tuple

		print("[XMLTVConverter] Processed: %s events" % count, file=log)
